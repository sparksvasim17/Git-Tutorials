import React, { useState } from 'react'

const Hooks = () => {
    const [fname, setFname] = useState('hello')    
    const [l_name, setLname] = useState('hello')    
    return (
      <>
    <div>first name : {fname}</div>    
    <div>lAST name : {l_name}</div>    
            <div>Hooks</div>            
            <label htmlFor="">First name</label>
            <input onChange={(e) => { setFname(e.target.value); }} />
            <label htmlFor="">Last name</label>
    <input onChange={(e)=>{setLname(e.target.value);}} />
            </>
  )
}

export default Hooks
